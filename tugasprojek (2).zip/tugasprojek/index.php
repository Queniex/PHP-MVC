<?php include("header.php"); ?>

<?php
$success = "";
$nilaiakhir = "";
$katakunci = (isset($_GET['katakunci'])) ? $_GET['katakunci'] : "";
if (isset($_GET['op'])) {
    $op     = $_GET['op'];
} else {
    $op     = "";
}
if ($op == 'delete') {
    $id = $_GET['id'];
    $sql1 = "delete from ligainggris where id = '$id'";
    $q1 = mysqli_query($conn, $sql1);
    if ($q1) {
        $success = "Berhasil hapus data";
    }
}
?>

<?php
if ($success) {
?>
    <div class="alert alert-success" role="alert">
        <?php echo $success ?>
    </div>
<?php
}
?>
<br>
<form class="row g-3" method="get">
    <div class="col-auto">
        <input type="text" class="form-control" placeholder="Masukkan Kata Kunci" name="katakunci" value="<?php echo $katakunci ?>" />
    </div>
    <div class="col-auto">
        <input type="submit" name="cari" value="Cari" class="btn btn-secondary" />
    </div>
</form>
<br>

<table class="table table-striped">
    <thead>
        <tr>
            <th class="col-1">No</th>
            <th>Club</th>
            <th>Main</th>
            <th>Kalah</th>
            <th>Menang</th>
            <th>Seri</th>
            <th>Score</th>
            <th class="col-2">Pengaturan</th>
        </tr>
    </thead>
    <tbody>

        <!-- pagination -->
        <?php
        $sqltambahan    = "";
        $per_halaman   = 5;
        if ($katakunci   != '') {
            $array_katakunci = explode(" ", $katakunci);
            for ($x = 0; $x < count($array_katakunci); $x++) {
                $sqlcari[] = "(nama like '%" . $array_katakunci[$x] . "%' or nim like '%" . $array_katakunci[$x] . "%')";
            }
            $sqltambahan   = "where " . implode(" or ", $sqlcari);
        }

        $sql1   = "select * from ligainggris $sqltambahan";
        $page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $start  = ($page > 1) ? ($page * $per_halaman) - $per_halaman : 0;
        $q1     = mysqli_query($conn, $sql1);
        $total  = mysqli_num_rows($q1);
        $pages  = ceil($total / $per_halaman);
        $nomor  = $start + 1;
        $sql1   = $sql1 . "order by id desc limit $start, $per_halaman";

        $q1     = mysqli_query($conn, $sql1);
        ?>
        <?php foreach ($q1 as $r1) : ?>
            <?php $nilaiakhir = $r1["Kalah"] + $r1["Menang"] + $r1["Seri"];
            $result = $nilaiakhir + 2; ?>
            <tr>
                <td><?php echo $nomor++ ?></td>
                <td><?php echo $r1['Club'] ?></td>
                <td><?php echo $r1['Main'] ?></td>
                <td><?php echo $r1['Kalah'] ?></td>
                <td><?php echo $r1['Menang'] ?></td>
                <td><?php echo $r1['Seri'] ?></td>
                <td><?php echo ceil($result); ?></td>

                <!-- edit dan hapus data -->
                <td>
                    <a href="create.php?id=<?php echo $r1['id'] ?>">
                        <span class="badge text-bg-warning">Edit</span>
                    </a>
                    <a href="index.php?op=delete&id=<?php echo $r1['id'] ?>" onclick="return confirm('Apakah yakin data ingin dihapus?')">
                        <span class="badge text-bg-danger">Delete</span>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- next page pagination -->
<nav aria-label="Page navigation example">
    <ul class="pagination">
        <?php
        $cari = isset($_GET['cari']) ? $_GET['cari'] : "";

        for ($i = 1; $i <= $pages; $i++) {
        ?>
            <li class="page-item">
                <a class="page-link" href="index.php?katakunci=<?php echo $katakunci ?>&cari=<?php echo $cari ?>&page=<?php echo $i ?>"><?php echo $i ?></a>
            </li>
        <?php
        }
        ?>
    </ul>
</nav>
<?php include("footer.php"); ?>

//terbaru
<?php
//inisialisasi sesiion
session_start();

//mengecek username pada session 
if( !isset($_SESSION['username'])) {
    $_SESSION['msg']= 'anda harus login untuk mengakses halaman ini';
    header('Location: login.php'); 
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, string-to-fit=no">

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm8liuXoPKFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<nav class='navbar navbar-expand-lg navbar-dark bg-dark text-light'>
    <div class="container">
        <a href="index.php" class="navbar-brand">KODEKREASI</a>
        <button class="navbar-toggler" type="button" data-togle="collapse">
            <span class="navbar-toggler-icon"></span> 
        </button>
        <ul class="navbar-nav ml-auto pt-2 pb-2">
            <li class="nav-item">
                <a href="index.php" class="nav-link text-light">Home</a>
            </li>
            <li class="nav-item ml-4">
                <a href="logout.php" class="nav-link text-light">Log Out </a>
            </li>
        </ul>
    </div>
</nav>
<div class="jumbotron jumbotrom-fluit bg-light" style="height:90vh">
    <div class="container">
    <h1 class="display-4 text-center mt-4">HOME</h1>
    <p class="lead text-center"> LOGIN OR REGISTER SUCCESFULLY ):</p>
    </div>
</div>

<!-- Bootstrap requitement jQuery pad posisi pertama, kemudian Popper.Js, dan yang terakhir Bootstrap JS-->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/18WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ60W/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
            