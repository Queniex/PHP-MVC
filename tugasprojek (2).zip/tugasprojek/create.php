<?php include("header.php"); ?>

<?php
$Club   = "";
$Main   = "";
$Kalah  = "";
$Menang = "";
$Seri   = "";
$error  = "";
$success = "";

// update data
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    $id = "";
}

if ($id != "") {
    $sql1       = "select * from ligainggris where id = '$id'";
    $q1         = mysqli_query($conn, $sql1);
    $r1         = mysqli_fetch_array($q1);
    $CLub       = $r1['Club'];
    $Main        = $r1['Main'];
    $Kalah      = $r1['Kalah'];
    $Menang        = $r1['Menang'];
    $Seri        = $r1['Seri'];

    if ($Club == '') {
        $error  = "Data tidak ditemukan";
    }
}

if (isset($_POST['submit'])) {
    $Club         = $_POST['Club'];
    $Main          = $_POST['Main'];
    $Kalah        = $_POST['Kalah'];
    $Menang          = $_POST['Menang'];
    $Seri          = $_POST['Seri'];

    if ($Club == '' or $Main == '') {
        $error      = "Silahkan masukkan data";
    }

    if (empty($error)) {
        if ($id != "") {
            $sql1   = "update ligainggris set Club = '$Club',Main='$Main',Kalah='$Kalah',Menang='$Menang',Seri='$Seri' where id = '$id'";
        } else {
            $sql1   = "insert into ligainggris(Club,Main,Kalah,Menang,Seri) values ('$Club','$Main','$Kalah','$Menang','$Seri')";
        }

        $q1   = mysqli_query($conn, $sql1);
        if ($q1) {
            $success    = "Sukses menambahkan data!";
        } else {
            $error      = "Gagal menambahkan data!";
        }
    }
}


?>
<h2 style="padding-top: 20px;">Masukkan Data Klasemen</h2>

<?php
if ($error) {
?>
    <div class="alert alert-danger" role="alert">
        <?php echo $error ?>
    </div>
<?php
}
?>

<?php
if ($success) {
?>
    <div class="alert alert-success" role="alert">
        <?php echo $success ?>
    </div>
<?php
}
?>

<form action="" method="POST">
    <div class="mb-3 row">
        <label for="nama" class="col-sm-2 col-form-label">Club</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Club"  name="Club">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="nim" class="col-sm-2 col-form-label">Main</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Main" name="Main">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="tugas" class="col-sm-2 col-form-label">Kalah</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Kalah" name="Kalah">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="uts" class="col-sm-2 col-form-label">Menang</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Menang" name="Menang">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="uas" class="col-sm-2 col-form-label">Seri</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Seri" name="Seri">
        </div>
    </div>
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <button class="btn btn-primary me-md-2" input type="submit" name="submit" value="Save">Save</button>
        <a href="index.php" class="btn btn-secondary" input type="cancel" name="cansel" value="cancel">Cancel</a>
    </div>
    <br>
</form>
<?php include("footer.php"); ?>