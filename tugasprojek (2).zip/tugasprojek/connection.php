<?php
$db = mysqli_connect("localhost", "root", "", "klasemen");

$conn   = mysqli_connect("localhost", "root", "", "klasemen");
if(!$conn) {
    die("Gagal terkoneksi!");
} //else {
//     echo "Koneksi berhasil!"
